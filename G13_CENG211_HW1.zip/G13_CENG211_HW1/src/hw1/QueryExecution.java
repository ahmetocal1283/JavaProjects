package hw1;

public class QueryExecution {

	StoreQuery query;
	FileIO file;

	public QueryExecution(StoreQuery query) {
		this.query = query;
		this.file = new FileIO();
	}

	public void start() {

		query.mostProfitableItemForTheWholeYear();

		query.mostProfitableCategoryForTheWholeYear();

		query.leastProfitableItemForTheWholeYear();

		query.leastProfitableCategoryForTheWholeYear();

		query.mostProfitableItemForaSingleSale();

		query.bestSellingItemForTheWholeYear();

		query.mostProfitableForEachMonth();

	}

}
