package hw1;

import java.io.IOException;
import java.text.ParseException;

public class ChainStoreApp {

    public static void main(String[] args) throws IOException, ParseException {
        FileIO f = new FileIO();
        AnnualSale annualSale = new AnnualSale();
        Item[] items = f.readItems("HW1_items.csv");
        for (Item item : items) {
            annualSale.itemTransactions[item.getId() - 1] = new ItemTransaction(item);
        }

        Transaction[][] s1 = f.readTransactions("HW1_Transactions_Store1.csv");
        Transaction[][] s2 = f.readTransactions("HW1_Transactions_Store2.csv");
        Transaction[][] s3 = f.readTransactions("HW1_Transactions_Store3.csv");
        Transaction[][] s4 = f.readTransactions("HW1_Transactions_Store4.csv");
        annualSale.setStore(0, s1);
        annualSale.setStore(1, s2);
        annualSale.setStore(2, s3);
        annualSale.setStore(3, s4);

        StoreQuery query = new StoreQuery(annualSale);

        QueryExecution queryexec = new QueryExecution(query);
        queryexec.start();
    }
}
