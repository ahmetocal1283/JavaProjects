package hw1;


public class AnnualSale {

    ItemTransaction[] itemTransactions = new ItemTransaction[32];


    public void setStore(int index, Transaction[][] transactions) {
        for (int i = 0; i < transactions.length; i++) {
            for (int m = 0; m < transactions[i].length; m++) {
                itemTransactions[i].getTransactions()[index][m] = transactions[i][m];
            }
        }
    }
}
