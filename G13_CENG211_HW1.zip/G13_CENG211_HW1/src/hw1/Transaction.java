package hw1;

public class Transaction {
	private double purchasePrice;        //Product price
	private double salesPrice;			// Sale Price
	private int numberOfSales;			// number of sales 
	
	
	public Transaction(double productPrice,double salesPrice,int numberOfSales) {
		this.purchasePrice=productPrice;
		this.salesPrice=salesPrice;
		this.numberOfSales=numberOfSales;
		
	}
	

		
	public double getPurchasePrice() {
		return purchasePrice;
	}
	public void setPurchasePrice(int productPrice) {
		this.purchasePrice = productPrice;
	}
	public double getSalesPrice() {
		return salesPrice;
	}
	public void setSalesPrice(int salesPrice) {
		this.salesPrice = salesPrice;
	}
	public int getNumberOfSales() {
		return numberOfSales;
	}
	public void setNumberOfSales(int numberOfSales) {
		this.numberOfSales = numberOfSales;
	}

	public double getSingleSaleProfit(){
		return this.getSalesPrice() - this.getPurchasePrice();
	}
	
	public double getProfit() {
		double totalProfit =0;
		totalProfit = this.getSingleSaleProfit() * getNumberOfSales();
		return totalProfit;
	}

}