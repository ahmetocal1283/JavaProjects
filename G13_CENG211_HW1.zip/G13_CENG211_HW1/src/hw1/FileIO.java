package hw1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileIO {

	public Item[] readItems(String filename) {

		Item[] items = new Item[32];
		try {

			BufferedReader inputStream = new BufferedReader(new FileReader(filename));
			Scanner sc = new Scanner(inputStream);
			int i = 0;
			while (sc.hasNextLine()) {

				String line1 = sc.nextLine();
				String[] details = line1.split(",");
				String name = details[0];
				int id = Integer.parseInt(details[1]);
				Category category = Category.valueOf(details[2]);
				Item item = new Item(id, name, category);
				items[i] = item;
				i = i + 1;

			}
			sc.close();
		} catch (FileNotFoundException e) {
			System.out.println("File " + filename + " not found.");
		}

		return items;
	}

	public Transaction[][] readTransactions(String filename) throws IOException {

		// two dimensional transaction array
		Transaction[][] transactions = new Transaction[32][12];

		try {

			FileReader fileReader1 = new FileReader(filename);
			String line = "";
			String[][] item = new String[32][37];
			int i = 0;

			BufferedReader br = new BufferedReader(fileReader1);

			while (((line = br.readLine()) != null)) {
				item[i] = line.split(",");
				i++;
			}

			br.close();
			int month = 0;
			for (int j = 0; j < 32; j++) {

				for (int k = 1; k < 37; k = k + 3) {

					double purchasePrice = Double.parseDouble(item[j][k]);
					double salesPrice = Double.parseDouble(item[j][k + 1]);
					int numberOfSales = Integer.parseInt(item[j][k + 2]);

					Transaction t = new Transaction(purchasePrice, salesPrice, numberOfSales);

					transactions[j][month] = t;
					month++;

				}
				month = 0;

			}

		} catch (FileNotFoundException exception) {
			System.out.println("File not found");
		} catch (IOException exception) {
			System.out.println(exception);
		}

		return transactions;
	}
}