package hw1;

public class StoreQuery {
    AnnualSale annualSale;

    public StoreQuery(AnnualSale annualSale) {
        this.annualSale = annualSale;
    }

    // Option 1
    public void mostProfitableItemForTheWholeYear() {
        int max = Integer.MIN_VALUE;
        Item maxItem = null;
        for (int i = 0; i < 32; i++) {
            ItemTransaction itemTransaction = annualSale.itemTransactions[i];
            int totalItemProfit = 0;
            for (int j = 0; j < 4; j++) {
                for (int k = 0; k < 12; k++) {
                    Transaction[][] transactions = itemTransaction.getTransactions();
                    Transaction transaction = transactions[j][k];

                    totalItemProfit += transaction.getProfit();
                }
            }

            if (totalItemProfit > max) {
                max = totalItemProfit;
                maxItem = itemTransaction.getItem();
            }
        }

        assert maxItem != null;

        System.out.println("Most profitable item for the whole year is " + maxItem.getName());
    }

    // Option 2
    public void mostProfitableCategoryForTheWholeYear() {
        int beverage = 0;
        int food = 0;
        int snack = 0;
        int home = 0;
        int personal = 0;


        for (int i = 0; i < 32; i++) {
            ItemTransaction itemTransaction = annualSale.itemTransactions[i];
            int totalItemProfit = 0;
            for (int j = 0; j < 4; j++) {
                for (int k = 0; k < 12; k++) {
                    Transaction[][] transactions = itemTransaction.getTransactions();
                    Transaction transaction = transactions[j][k];

                    totalItemProfit += transaction.getProfit();
                }
            }

            Item item = itemTransaction.getItem();
            switch (item.getCategory()) {
                case Food:
                    food += totalItemProfit;
                    break;
                case Beverage:
                    beverage += totalItemProfit;
                    break;
                case Snack:
                    snack += totalItemProfit;
                    break;
                case Home:
                    home += totalItemProfit;
                    break;
                case Personal:
                    personal += totalItemProfit;
                    break;
            }
        }

        int value = 0;
        Category category;
        if (beverage > food) {
            category = Category.Beverage;
            value = beverage;
        } else {
            category = Category.Food;
            value = food;
        }

        if (snack > value) {
            value = snack;
            category = Category.Snack;
        }

        if (home > value) {
            value = home;
            category = Category.Home;
        }

        if (personal > value) {
            category = Category.Personal;
        }

        System.out.println("Most profitable category for the whole year is " + category.name());
    }

    // Option 3
    public void leastProfitableItemForTheWholeYear() {
        int min = Integer.MAX_VALUE;
        Item minItem = null;
        for (int i = 0; i < 32; i++) {
            ItemTransaction itemTransaction = annualSale.itemTransactions[i];
            int totalItemProfit = 0;
            for (int j = 0; j < 4; j++) {
                for (int k = 0; k < 12; k++) {
                    Transaction[][] transactions = itemTransaction.getTransactions();
                    Transaction transaction = transactions[j][k];

                    totalItemProfit += transaction.getProfit();
                }
            }

            if (totalItemProfit < min) {
                min = totalItemProfit;
                minItem = itemTransaction.getItem();
            }
        }

        assert minItem != null;

        System.out.println("Least profitable item for the whole year is " + minItem.getName());
    }

    // Option 4
    public void leastProfitableCategoryForTheWholeYear() {
        int beverage = 0;
        int food = 0;
        int snack = 0;
        int home = 0;
        int personal = 0;


        for (int i = 0; i < 32; i++) {
            ItemTransaction itemTransaction = annualSale.itemTransactions[i];
            int totalItemProfit = 0;
            for (int j = 0; j < 4; j++) {
                for (int k = 0; k < 12; k++) {
                    Transaction[][] transactions = itemTransaction.getTransactions();
                    Transaction transaction = transactions[j][k];

                    totalItemProfit += transaction.getProfit();
                }
            }

            Item item = itemTransaction.getItem();
            switch (item.getCategory()) {
                case Food:
                    food += totalItemProfit;
                    break;
                case Beverage:
                    beverage += totalItemProfit;
                    break;
                case Snack:
                    snack += totalItemProfit;
                    break;
                case Home:
                    home += totalItemProfit;
                    break;
                case Personal:
                    personal += totalItemProfit;
                    break;
            }
        }

        int value = Integer.MAX_VALUE;
        Category category;
        if (beverage < food) {
            category = Category.Beverage;
            value = beverage;
        } else {
            category = Category.Food;
            value = food;
        }

        if (snack < value) {
            value = snack;
            category = Category.Snack;
        }

        if (home < value) {
            value = home;
            category = Category.Home;
        }

        if (personal < value) {
            category = Category.Personal;
        }

        System.out.println("Least profitable category for the whole year is " + category.name());
    }

    // Option 5
    public void mostProfitableItemForaSingleSale() {
        double max = Integer.MIN_VALUE;
        Item maxItem = null;
        for (int i = 0; i < 32; i++) {
            ItemTransaction itemTransaction = annualSale.itemTransactions[i];
            for (int j = 0; j < 4; j++) {
                for (int k = 0; k < 12; k++) {
                    Transaction[][] transactions = itemTransaction.getTransactions();
                    Transaction transaction = transactions[j][k];

                    if (max < transaction.getSingleSaleProfit()) {
                        max = transaction.getSingleSaleProfit();
                        maxItem = itemTransaction.getItem();
                    }

                }
            }
        }

        assert maxItem != null;

        System.out.println("Most profitable item for a single sale is " + maxItem.getName());
    }

    // Option 6
    public void bestSellingItemForTheWholeYear() {
        int max = Integer.MIN_VALUE;
        Item maxItem = null;
        for (int i = 0; i < 32; i++) {
            ItemTransaction itemTransaction = annualSale.itemTransactions[i];
            int totalItemCount = 0;
            for (int j = 0; j < 4; j++) {
                for (int k = 0; k < 12; k++) {
                    Transaction[][] transactions = itemTransaction.getTransactions();
                    Transaction transaction = transactions[j][k];

                    totalItemCount += transaction.getNumberOfSales();
                }
            }

            if (totalItemCount > max) {
                max = totalItemCount;
                maxItem = itemTransaction.getItem();
            }
        }

        assert maxItem != null;

        System.out.println("Best selling item for whole year is " + maxItem.getName());
    }

    // Option 7
    public void mostProfitableForEachMonth() {
        for (int m = 0; m < 12; m++) {
            int max = Integer.MIN_VALUE;
            int maxStore = -1;
            for (int s = 0; s < 4; s++) {
                int totalProfit = 0;
                for (int i = 0; i < 32; i++) {
                    ItemTransaction itemTransaction = annualSale.itemTransactions[i];
                    Transaction transaction = itemTransaction.getTransactions()[s][m];
                    totalProfit += transaction.getProfit();
                }

                if (totalProfit > max) {
                    max = totalProfit;
                    maxStore = s;
                }
            }

            System.out.println("Month " + (m + 1) + " - Store " + (maxStore + 1) + " is the most profitable store.");
        }
    }

}
