package homework3;

public interface ICargoPackage<T> {

	public T getCargoCode();
	
	public int getSize();
	
	public int getWeight();
	
	public int getWidth();
	
	public int getHeight();
	
	public int getLength();
	
	
	
}
