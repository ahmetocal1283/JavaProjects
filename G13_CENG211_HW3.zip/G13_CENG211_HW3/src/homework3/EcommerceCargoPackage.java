package homework3;

import java.util.List;

public abstract class EcommerceCargoPackage<T> extends CargoPackage<T> implements IECommerceCargoPackage<T> {
	private Status currentStatus;

	public EcommerceCargoPackage(int weight, int width, int lenght, int height, T cargoCode) {
		super(weight, width, lenght, height, cargoCode);
	}

	public EcommerceCargoPackage() {
		super();
	}

	public abstract boolean checkDailyLimit(List<CargoPackage<T>> list);

	public Status getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(Status currentStatus) {
		this.currentStatus = currentStatus;
	}

	
}
