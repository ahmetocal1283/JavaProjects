package homework3;

public enum Status {

	Accepted,
	NotAccepted
	
}
