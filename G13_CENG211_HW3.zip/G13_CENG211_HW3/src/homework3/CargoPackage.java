package homework3;

import java.util.Random;

public abstract class CargoPackage<T> implements ICargoPackage<T> {

	private int weight;
	private int width;
	private int lenght;
	private int height;
	private T cargoCode;

	public CargoPackage(int weight, int width, int lenght, int height, T cargoCode) {
		this.weight = weight;
		this.width = width;
		this.lenght = lenght;
		this.height = height;
		this.cargoCode = cargoCode;
	}

	public CargoPackage() {
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getLenght() {
		return lenght;
	}

	public void setLenght(int lenght) {
		this.lenght = lenght;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public T getCargoCode() {
		return cargoCode;
	}

	public void setCargoCode(T cargoCode) {
		this.cargoCode = cargoCode;
	}

	public double desi() {
		return (getWeight() * getLenght() * getHeight()) / 3000;
	}

	@Override
	public int getSize() {
		return (int) Math.max(desi(), weight);
	}

	public static int createCargoCode(int n) {
		int m = (int) Math.pow(10, n - 1);
		return m + new Random().nextInt(9 * m);
	}
	
	public Days getDeliveryDay() {
	
		return Days.Friday;
			
	
	}

}
