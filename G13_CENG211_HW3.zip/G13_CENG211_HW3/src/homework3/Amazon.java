package homework3;

import java.util.List;

public class Amazon extends EcommerceCargoPackage<Integer> {

	private final static int dailyLimit = 5;

	public Amazon(int cargoCode, int weight, int width, int lenght, int height) {
		super(weight, width, lenght, height, cargoCode);
	}

	public Amazon() {
		super();
	}


	@Override
	public int getLength() {
		// TODO Auto-generated method stub
		return 0;
	}

	public static int getDailylimit() {
		return dailyLimit;
	}

	public int getStatus() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getDeliveryDate() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean checkDailyLimit(List<CargoPackage<Integer>> list) {
		if (list.size() < dailyLimit) {
			setCurrentStatus(Status.Accepted);
			return true;
		}

		else
			setCurrentStatus(Status.NotAccepted);
		return false;
	}
}
