package homework3;


public enum Days {
	Monday,
	Tuesday,
	Wednesday,
	Thursday,
	Friday,
	Saturday,
	Sunday;
	
	public boolean checkOffDay(Days day) {

		if (day.equals(Sunday)) {
			return false;
		} else
			return true;
	}
	

}
