package homework3;

public interface IECommerceCargoPackage<T> extends ICargoPackage<T> {

}
