package homework3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class FileIO<T> {

	private static List<CargoPackage<?>> cargoList = new ArrayList<>();
	private static List<Integer> cargoListType = new ArrayList<Integer>();

	public static List<CargoPackage<?>> read(String file) {

		BufferedReader br = null;
		String line = "";

		try {

			String type = "";
			int weight;
			int width;
			int lenght;
			int height;
			long senderId;
			String senderName;
			String recipientName;
			String recipientAddress;
			String ecommerceSiteName;
			int cargoCode1 = 0;
			int cargoCodeA;
			int cargoCodeT;
			String cargoCodeN;
			String cargoCodeH;

			br = new BufferedReader(new FileReader(file));

			StringTokenizer st = null;

			while ((line = br.readLine()) != null) {
				st = new StringTokenizer(line, ";");
				type = st.nextToken();

				if (type.equals("Normal")) {
					cargoListType.add(0);
					senderId = Long.parseLong(st.nextToken());
					senderName = st.nextToken();
					recipientName = st.nextToken();
					recipientAddress = st.nextToken();
					weight = Integer.parseInt(st.nextToken());
					width = Integer.parseInt(st.nextToken());
					lenght = Integer.parseInt(st.nextToken());
					height = Integer.parseInt(st.nextToken());

					NormalCargoPackage normalCargoPackage = new NormalCargoPackage(senderId, senderName, recipientName,
							recipientAddress, weight, width, lenght, height, cargoCode1);
					cargoList.add(normalCargoPackage);
					
				} else if (type.equals("Ecommerce")) {
					
					ecommerceSiteName = st.nextToken();
					if (ecommerceSiteName.equals("Amazon")) {
						cargoListType.add(1);
						cargoCodeA = Integer.parseInt(st.nextToken());
						weight = Integer.parseInt(st.nextToken());
						width = Integer.parseInt(st.nextToken());
						lenght = Integer.parseInt(st.nextToken());
						height = Integer.parseInt(st.nextToken());

						EcommerceCargoPackage<Integer> amazonCargoPackage = new Amazon(cargoCodeA, weight, width,
								lenght, height);
						cargoList.add(amazonCargoPackage);

					} else if (ecommerceSiteName.equals("Trendyol")) {
						cargoListType.add(2);
						cargoCodeT = Integer.parseInt(st.nextToken());
						weight = Integer.parseInt(st.nextToken());
						width = Integer.parseInt(st.nextToken());
						lenght = Integer.parseInt(st.nextToken());
						height = Integer.parseInt(st.nextToken());

						EcommerceCargoPackage<Integer> trendyolCargoPackage = new Trendyol(cargoCodeT, weight, width,
								lenght, height);
						cargoList.add(trendyolCargoPackage);

					} else if (ecommerceSiteName.equals("N11")) {
						cargoListType.add(3);
						cargoCodeN = st.nextToken();
						weight = Integer.parseInt(st.nextToken());
						width = Integer.parseInt(st.nextToken());
						lenght = Integer.parseInt(st.nextToken());
						height = Integer.parseInt(st.nextToken());

						EcommerceCargoPackage<String> n11CargoPackage = new N11(cargoCodeN, weight, width, lenght,
								height);
						cargoList.add(n11CargoPackage);

					} else if (ecommerceSiteName.equals("Hepsiburada")) {
						cargoListType.add(4);
						cargoCodeH = st.nextToken();
						weight = Integer.parseInt(st.nextToken());
						width = Integer.parseInt(st.nextToken());
						lenght = Integer.parseInt(st.nextToken());
						height = Integer.parseInt(st.nextToken());

						EcommerceCargoPackage<String> hepsiburadaCargoPackage = new Hepsiburada(cargoCodeH, weight, width,
								lenght, height);
						cargoList.add(hepsiburadaCargoPackage);

					}

				}

			}
		} catch (Exception e) {
			System.out.println("Exception while reading csv file: " + e);
		}
		return cargoList;
	}

	public static List<Integer> getCargoListType() {
		return cargoListType;
	}

	public static void setCargoListType(List<Integer> cargoListType) {
		FileIO.cargoListType = cargoListType;
	}

}