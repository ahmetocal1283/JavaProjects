package homework3;

import java.util.ArrayList;
import java.util.List;

public class CargoPackageRecord<T> {

	public List<CargoPackage<?>> cargoPackageList;
	private static List<?> cargoListType = new ArrayList<Integer>();

	CargoPackage<Integer> normal = new NormalCargoPackage();

	CargoPackage<Integer> trendyol = new Trendyol();
	CargoPackage<Integer> amazon = new Amazon();
	CargoPackage<String> n11 = new N11();
	CargoPackage<String> hepsiburada = new Hepsiburada();

	public CargoPackageRecord() {
		this.cargoPackageList = FileIO.read("HW3_PackagesToAccept.csv");
		this.cargoListType = FileIO.getCargoListType();
		
	}

	public static List<?> getCargoListType() {
		return cargoListType;
	}

	public static void setCargoListType(List<Integer> cargoListType) {
		CargoPackageRecord.cargoListType = cargoListType;
	}

	public List<CargoPackage<?>> getNormalCargoPackageList() {
		List<CargoPackage<?>> cp = new ArrayList<>();
		for (int i = 0; i < getSizeOfList(); i++) {
			if (normal instanceof NormalCargoPackage) {
			//	System.out.println(((NormalCargoPackage) normal).getSenderName());
				cp.add(cargoPackageList.get(i));
			}
		}
		return cp;
	}

	public List<CargoPackage<?>> getEcommerceCargoPackageList() {
		List<CargoPackage<?>> cp = new ArrayList<>();
		for (int i = 0; i < getSizeOfList(); i++) {
			if (cargoPackageList.get(i) instanceof EcommerceCargoPackage) {
				cp.add(cargoPackageList.get(i));
			}
		}
		return cp;
	}
	
	public int getSizeOfList() {
		return cargoPackageList.size();
	}

}