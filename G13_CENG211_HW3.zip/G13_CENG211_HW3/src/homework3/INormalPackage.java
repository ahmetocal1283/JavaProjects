package homework3;

public interface INormalPackage extends ICargoPackage<Integer>{

	public long getSenderId();

	public String getSenderName();

	public String getRecipientName();

	public String getRecipientAddress();

	public double calculatePrice();
}
