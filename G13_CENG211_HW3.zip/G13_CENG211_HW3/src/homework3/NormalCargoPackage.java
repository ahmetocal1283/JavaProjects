package homework3;

public class NormalCargoPackage extends CargoPackage<Integer>  {

	private long senderId;
	private String senderName;
	private String recipientName;
	private String recipientAddress;

	public NormalCargoPackage(long senderId, String senderName, String recipientName, String recipientAddress,
			int weight, int width, int lenght, int height, int cargoCode) {
		super(weight, width, lenght, height, createCargoCode(7));
		this.senderId = senderId;
		this.senderName = senderName;
		this.recipientName = recipientName;
		this.recipientAddress = recipientAddress;
	}



	public NormalCargoPackage() {
		super();
	}


	public long getSenderId() {
		return senderId;
	}

	
	public String getSenderName() {
		return senderName;
	}

	
	public String getRecipientName() {
		return recipientName;
	}

	public String getRecipientAddress() {
		return recipientAddress;
	}

	@Override
	public int getSize() {
		return super.getSize();
	}

	@Override
	public int getLength() {
		// TODO Auto-generated method stub
		return 0;
	}

	
	public double calculatePrice() {
		double price;
		price = 18.5 + 3 * getSize();
		return price;
	}




}
