package homework3;

public class CargoAcceptanceApp {

	public static void main(String[] args) {

		CargoManager manager = new CargoManager();
		manager.start();



	}

}
