package homework3;

import java.util.ArrayList;
import java.util.List;

public class CargoManager {

	private CargoPackageRecord<?> record;

	public CargoManager() {
		this.record = new CargoPackageRecord<>();
	}

	public void start() {
		System.out.println("Welcome!");
		System.out.println("Number of Accepted Cargo: " + numAccepted());
		System.out.println("Number of Not Accepted Cargo: " + numNotAccepted());
		System.out.println("Here are the details:");
		System.out.println("Normal Cargo Packages:");

		List<CargoPackage<?>> normalList = record.getNormalCargoPackageList();

		System.out.println(
				"\nNo Cargo Code Sender ID Sender Name Recipient Name Recipient Address Size Price Delivery Day");

		for (int i = 0; i < normalList.size(); i++) {

			if (normalList.get(i) instanceof NormalCargoPackage) {
				System.out.println(i + 1 + " " + normalList.get(i).getCargoCode() + " "
						+ ((NormalCargoPackage) normalList.get(i)).getSenderId() + " "
						+ ((NormalCargoPackage) normalList.get(i)).getSenderName() + " "
						+ ((NormalCargoPackage) normalList.get(i)).getRecipientName() + " "
						+ ((NormalCargoPackage) normalList.get(i)).getRecipientAddress() + " "
						+ ((NormalCargoPackage) normalList.get(i)).getSize() + " "
						+ ((NormalCargoPackage) normalList.get(i)).calculatePrice() + " "
						+ ((NormalCargoPackage) normalList.get(i)).getDeliveryDay());
			}
		}

		System.out.println("E-commerce Cargo Packages:");

		List<CargoPackage<?>> ecommerceList = record.getEcommerceCargoPackageList();

		System.out.println("\nNo E-commerce Site Cargo Code Status Size Delivery Day");
		for (int i = 0; i < ecommerceList.size(); i++) {
			if (ecommerceList.get(i) instanceof Trendyol) {
				System.out
						.println(i + 1 + " " + " " + "Trendyol" + " " + ((Trendyol) ecommerceList.get(i)).getCargoCode()
								+ " " + ((Trendyol) ecommerceList.get(i)).getCurrentStatus() + " "
								+ ((Trendyol) ecommerceList.get(i)).getSize() + " "
								+ ((Trendyol) ecommerceList.get(i)).getDeliveryDay());
			}
			if (ecommerceList.get(i) instanceof Amazon) {
				System.out.println(i + 1 + " " + " " + "Amazon" + " " + ((Amazon) ecommerceList.get(i)).getCargoCode()
						+ " " + ((Amazon) ecommerceList.get(i)).getCurrentStatus() + " "
						+ ((Amazon) ecommerceList.get(i)).getSize() + " "
						+ ((Amazon) ecommerceList.get(i)).getDeliveryDay());
			}

			if (ecommerceList.get(i) instanceof N11) {
				System.out.println(i + 1 + " " + " " + "N11" + " " + ((N11) ecommerceList.get(i)).getCargoCode() + " "
						+ ((N11) ecommerceList.get(i)).getCurrentStatus() + " " + ((N11) ecommerceList.get(i)).getSize()
						+ " " + ((N11) ecommerceList.get(i)).getDeliveryDay());
			}

			if (ecommerceList.get(i) instanceof Hepsiburada) {
				System.out.println(
						i + 1 + " " + " " + "Hepsiburada" + " " + ((Hepsiburada) ecommerceList.get(i)).getCargoCode()
								+ " " + ((Hepsiburada) ecommerceList.get(i)).getCurrentStatus() + " "
								+ ((Hepsiburada) ecommerceList.get(i)).getSize() + " "
								+ ((Hepsiburada) ecommerceList.get(i)).getDeliveryDay());
			}
		}

	}

	public int numNotAccepted() {
		int result = 0;
		List<CargoPackage<?>> ecommerceList = record.getEcommerceCargoPackageList();
		List<CargoPackage<Integer>> trendyolList = new ArrayList<>();
		List<CargoPackage<Integer>> amazonList = new ArrayList<>();
		List<CargoPackage<String>> n11List = new ArrayList<>();
		List<CargoPackage<String>> hepsiburadaList = new ArrayList<>();

		for (int i = 0; i < ecommerceList.size(); i++) {
			if (ecommerceList.get(i) instanceof Trendyol) {
				trendyolList.add((CargoPackage<Integer>) ecommerceList.get(i));
				if (((EcommerceCargoPackage) ecommerceList.get(i)).checkDailyLimit(trendyolList) == false) {
					result += 1;
				}
			}
			if (ecommerceList.get(i) instanceof Amazon) {
				amazonList.add((CargoPackage<Integer>) ecommerceList.get(i));
				if (((EcommerceCargoPackage) ecommerceList.get(i)).checkDailyLimit(n11List) == false) {
					result += 1;
				}
			}
			if (ecommerceList.get(i) instanceof N11) {
				n11List.add((CargoPackage<String>) ecommerceList.get(i));
				if (((EcommerceCargoPackage) ecommerceList.get(i)).checkDailyLimit(n11List) == false) {
					result += 1;
				}
			}
			if (ecommerceList.get(i) instanceof Hepsiburada) {
				hepsiburadaList.add((CargoPackage<String>) ecommerceList.get(i));
				if (((EcommerceCargoPackage) ecommerceList.get(i)).checkDailyLimit(hepsiburadaList) == false) {
					result += 1;
				}
			}
		}

		return result;
	}

	public int numAccepted() {
		int result = 0;
		List<CargoPackage<?>> ecommerceList = record.getEcommerceCargoPackageList();
		List<CargoPackage<Integer>> trendyolList = new ArrayList<>();
		List<CargoPackage<Integer>> amazonList = new ArrayList<>();
		List<CargoPackage<String>> n11List = new ArrayList<>();
		List<CargoPackage<String>> hepsiburadaList = new ArrayList<>();

		for (int i = 0; i < ecommerceList.size(); i++) {
			if (ecommerceList.get(i) instanceof Trendyol) {
				trendyolList.add((CargoPackage<Integer>) ecommerceList.get(i));
				if (((EcommerceCargoPackage) ecommerceList.get(i)).checkDailyLimit(trendyolList) == true) {
					result += 1;

				}

			}
			if (ecommerceList.get(i) instanceof Amazon) {
				amazonList.add((CargoPackage<Integer>) ecommerceList.get(i));
				if (((EcommerceCargoPackage) ecommerceList.get(i)).checkDailyLimit(amazonList) == true) {
					result += 1;
				}
			}
			if (ecommerceList.get(i) instanceof N11) {
				n11List.add((CargoPackage<String>) ecommerceList.get(i));
				if (((EcommerceCargoPackage) ecommerceList.get(i)).checkDailyLimit(n11List) == true) {
					result += 1;
				}
			}
			if (ecommerceList.get(i) instanceof Hepsiburada) {
				hepsiburadaList.add((CargoPackage<String>) ecommerceList.get(i));
				if (((EcommerceCargoPackage) ecommerceList.get(i)).checkDailyLimit(hepsiburadaList) == true) {
					result += 1;
				}
			}
		}

		return result;
	}

}
