package homework3;

import java.util.List;

public class Hepsiburada extends EcommerceCargoPackage<String> {

	private final static int dailyLimit = 7;

	public Hepsiburada(String cargoCode, int weight, int width, int lenght, int height) {
		super(weight, width, lenght, height, cargoCode);
		// TODO Auto-generated constructor stub
	}

	public Hepsiburada() {
		super();
	}



	@Override
	public int getLength() {
		// TODO Auto-generated method stub
		return 0;
	}

	public static int getDailylimit() {
		return dailyLimit;
	}

	public int getStatus() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getDeliveryDate() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean checkDailyLimit(List<CargoPackage<String>> list) {
		if (list.size() < dailyLimit) {
			setCurrentStatus(Status.Accepted);
			return true;
		}

		else
			setCurrentStatus(Status.NotAccepted);
		return false;
	}
}
