
public class Premises extends InsuredValue {

	private String premisesCity;
	private int numberOfFloors;
	private int yearOfConstruction;
	private String typeOfConstruction;
	private int surfaceArea;

	public Premises(String insuranceNumber, int yearOfInsurance, String premisesCity, int numberOfFloors,
			int yearOfConstruction, String typeOfConstruction, int surfaceArea) {
		super(insuranceNumber, yearOfInsurance);
		this.premisesCity = premisesCity;
		this.numberOfFloors = numberOfFloors;
		this.yearOfConstruction = yearOfConstruction;
		this.typeOfConstruction = typeOfConstruction;
		this.surfaceArea = surfaceArea;
	}

	public String getPremisesCity() {
		return premisesCity;
	}

	public void setPremisesCity(String premisesCity) {
		this.premisesCity = premisesCity;
	}

	public int getNumberOfFloors() {
		return numberOfFloors;
	}

	public void setNumberOfFloors(int numberOfFloors) {
		this.numberOfFloors = numberOfFloors;
	}

	public int getYearOfConstruction() {
		return yearOfConstruction;
	}

	public void setYearOfConstruction(int yearOfConstruction) {
		this.yearOfConstruction = yearOfConstruction;
	}

	public String getTypeOfConstruction() {
		return typeOfConstruction;
	}

	public void setTypeOfConstruction(String typeOfConstruction) {
		this.typeOfConstruction = typeOfConstruction;
	}

	public int getSurfaceArea() {
		return surfaceArea;
	}

	public void setSurfaceArea(int surfaceArea) {
		this.surfaceArea = surfaceArea;
	}

	public double getPremisesCityRiskFactorValue() {
		double premisesCityRiskFactorValue;

		if (premisesCity.equals("�zmir")) {
			premisesCityRiskFactorValue = 0.4;
		} else if (premisesCity.equals("�stanbul")) {
			premisesCityRiskFactorValue = 0.6;
		} else if (premisesCity.equals("Ankara")) {
			premisesCityRiskFactorValue = 0.15;
		} else
			premisesCityRiskFactorValue = 0.25;

		return premisesCityRiskFactorValue;
	}

	public double getNumberOfFloorsRiskFactorValue() {
		double numberOfFloorsRiskFactorValue = 0;
		if ((numberOfFloors > 0) && (numberOfFloors < 4)) {
			numberOfFloorsRiskFactorValue = 0.1;
		} else if ((numberOfFloors > 3) && (numberOfFloors < 8)) {
			numberOfFloorsRiskFactorValue = 0.25;
		} else if ((numberOfFloors > 7) && (numberOfFloors < 19)) {
			numberOfFloorsRiskFactorValue = 0.5;
		} else if (numberOfFloors > 18) {
			numberOfFloorsRiskFactorValue = 0.85;
		}
		return numberOfFloorsRiskFactorValue;

	}

	public double getYearOfConstructionRiskFactorValue() {
		double yearOfConstructionRiskFactorValue = 0;
		if (yearOfConstruction < 1975) {
			yearOfConstructionRiskFactorValue = 0.58;
		} else if ((yearOfConstruction > 1975) && (yearOfConstruction < 1999)) {
			yearOfConstructionRiskFactorValue = 0.32;
		} else if (yearOfConstruction > 1999) {
			yearOfConstructionRiskFactorValue = 0.1;
		}
		return yearOfConstructionRiskFactorValue;
	}

	public double getTypeOfConstructionRiskFactorValue() {
		double typeOfConstructionRiskFactorValue;
		if (typeOfConstruction.equals("Steel")) {
			typeOfConstructionRiskFactorValue = 0.1;
		} else if (typeOfConstruction.equals("Concrete")) {
			typeOfConstructionRiskFactorValue = 0.37;
		} else if (typeOfConstruction.equals("Wood")) {
			typeOfConstructionRiskFactorValue = 0.58;
		} else
			typeOfConstructionRiskFactorValue = 0.92;
		return typeOfConstructionRiskFactorValue;
	}

}
