
public class Housing extends Premises {

	private String residentSituation;

	public Housing(String insuranceNumber, int yearOfInsurance, String premisesCity, int numberOfFloors,
			int yearOfConstruction, String typeOfConstruction, int surfaceArea, String residentSituation) {
		super(insuranceNumber, yearOfInsurance, premisesCity, numberOfFloors, yearOfConstruction, typeOfConstruction,
				surfaceArea);
		this.residentSituation = residentSituation;
	}

	public String getResidentSituation() {
		return residentSituation;
	}

	public void setResidentSituation(String residentSituation) {
		this.residentSituation = residentSituation;
	}

	public double getResidentSituationRiskFactorValue() {
		double residentSituationRiskFactorValue = 0;
		if (residentSituation.equals("tenant")) {
			residentSituationRiskFactorValue = 0.18;
		} else if (residentSituation.equals("landlord")) {
			residentSituationRiskFactorValue = 0.42;
		}
		return residentSituationRiskFactorValue;
	}

	@Override
	public double calculateRiskFactor() {
		double result = 0;
		double premisesCityRiskFactorValue = getPremisesCityRiskFactorValue();

		double numberOfFloorsRiskFactorValue = getNumberOfFloorsRiskFactorValue();

		double yearOfTypeRiskFactorValue = getYearOfConstructionRiskFactorValue();

		double typeOfConstructionRiskFactorValue = getTypeOfConstructionRiskFactorValue();

		double surfaceAreaRiskFactorValue = getSurfaceArea();

		result = ((premisesCityRiskFactorValue * numberOfFloorsRiskFactorValue * yearOfTypeRiskFactorValue
				* typeOfConstructionRiskFactorValue) * (surfaceAreaRiskFactorValue))
				/ getResidentSituationRiskFactorValue();
		return result;
	}
}
