
public class Household extends Insurance {

	
	public Household() {
		super();
	}

	@Override
	public double calculatePolicyCharge(InsuredValue insuredValue) {
		double result = 0;
		double riskFactor = insuredValue.calculateRiskFactor();
		double fixedFee = getRandomFixedFee(1000, 3000);
		result = (fixedFee * Math.pow(riskFactor, 2));
		double rank = 2020 - insuredValue.getYearOfInsurance();
		if(rank>2) {
			result = result * 0.9;
		}
		return result;
	}


}
