
public class Workplace extends Premises {

	private int annualRevenue;

	public Workplace(String insuranceNumber, int yearOfInsurance, String premisesCity, int numberOfFloors,
			int yearOfConstruction, String typeOfConstruction, int surfaceArea, int annualRevenue) {
		super(insuranceNumber, yearOfInsurance, premisesCity, numberOfFloors, yearOfConstruction, typeOfConstruction,
				surfaceArea);
		this.annualRevenue = annualRevenue;
	}

	@Override
	public double calculateRiskFactor() {
		double result;
		double premisesCityRiskFactorValue = getPremisesCityRiskFactorValue();
		double numberOfFloorsRiskFactorValue = getNumberOfFloorsRiskFactorValue();
		double yearOfTypeRiskFactorValue = getYearOfConstructionRiskFactorValue();
		double typeOfConstructionRiskFactorValue = getTypeOfConstructionRiskFactorValue();
		double surfaceAreaRiskFactorValue = getSurfaceArea();

		result = (premisesCityRiskFactorValue * numberOfFloorsRiskFactorValue * yearOfTypeRiskFactorValue
				* typeOfConstructionRiskFactorValue) * (surfaceAreaRiskFactorValue * 0.2) * (annualRevenue * 0.003);
		return result;
	}

	public int getAnnualRevenue() {
		return annualRevenue;
	}

	public void setAnnualRevenue(int annualRevenue) {
		this.annualRevenue = annualRevenue;
	}

}
