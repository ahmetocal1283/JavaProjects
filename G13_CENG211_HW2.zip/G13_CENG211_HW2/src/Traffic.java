
public class Traffic extends Insurance {

	public Traffic() {
		// TODO Auto-generated constructor stub
	}
	


	@Override
	public double calculatePolicyCharge(InsuredValue insuredValue) {
		double result = 0;
		double riskFactor = insuredValue.calculateRiskFactor();
		double fixedFee = getRandomFixedFee(1000, 3000);
		result = (fixedFee * 90 / 100) + (fixedFee * Math.pow(riskFactor, 0.5));
		double rank = 2020 - insuredValue.getYearOfInsurance();
		if(rank>1) {
			result = result * 0.8;
		}
		return result;
	}

}
