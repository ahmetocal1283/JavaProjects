
public class Truck extends Vehicle {

	private String typeOfTruckBed;

	public Truck(String insuranceNumber, int yearOfInsurance, String plateCity, double engineVolume, int yearOfProduction,
			String typeOfGear, int fuelTankVolume, String typeOfTruckBed) {
		super(insuranceNumber, yearOfInsurance, plateCity, engineVolume, yearOfProduction, typeOfGear, fuelTankVolume);
		this.typeOfTruckBed = typeOfTruckBed;
	}

	@Override
	public double calculateRiskFactor() {
		// TODO Auto-generated method stub
		return super.calculateRiskFactor();
	}

	public String getTypeOfTruckBed() {
		return typeOfTruckBed;
	}

	public void setTypeOfTruckBed(String typeOfTruckBed) {
		this.typeOfTruckBed = typeOfTruckBed;
	}

}
