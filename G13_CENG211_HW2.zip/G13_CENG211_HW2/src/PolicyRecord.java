import java.io.IOException;
import java.util.ArrayList;

public class PolicyRecord {

	private ArrayList<InsuredValue> insuredValueList;

	public PolicyRecord() throws IOException {
		this.insuredValueList = FileIO.read("HW2_InsuredValues.csv");
	}

	public ArrayList<InsuredValue> getWorkPlaceList() {
		ArrayList<InsuredValue> iv = new ArrayList<>();
		for (int i = 0; i < insuredValueList.size(); i++) {
			String id = insuredValueList.get(i).getInsuranceNumber();
			if (id.charAt(0) == 'W') {
				iv.add(insuredValueList.get(i));
			}
		}
		return iv;
	}

	public ArrayList<InsuredValue> getHousingList() {
		ArrayList<InsuredValue> iv = new ArrayList<>();
		for (int i = 0; i < insuredValueList.size(); i++) {
			String id = insuredValueList.get(i).getInsuranceNumber();
			if (id.charAt(0) == 'H') {
				iv.add(insuredValueList.get(i));
			}
		}
		return iv;
	}

	public ArrayList<InsuredValue> getPersonList() {
		ArrayList<InsuredValue> iv = new ArrayList<>();
		for (int i = 0; i < insuredValueList.size(); i++) {
			String id = insuredValueList.get(i).getInsuranceNumber();
			if (id.charAt(0) == 'P') {
				iv.add(insuredValueList.get(i));
			}
		}
		return iv;
	}

	public ArrayList<InsuredValue> getAutomobileList() {
		ArrayList<InsuredValue> iv = new ArrayList<>();
		for (int i = 0; i < insuredValueList.size(); i++) {
			String id = insuredValueList.get(i).getInsuranceNumber();
			if (id.charAt(0) == 'A') {
				iv.add(insuredValueList.get(i));
			}
		}
		return iv;
	}

	public ArrayList<InsuredValue> getTruckList() {
		ArrayList<InsuredValue> iv = new ArrayList<>();
		for (int i = 0; i < insuredValueList.size(); i++) {
			String id = insuredValueList.get(i).getInsuranceNumber();
			if (id.charAt(0) == 'T') {
				iv.add(insuredValueList.get(i));
			}
		}
		return iv;
	}

}
