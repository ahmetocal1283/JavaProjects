import java.util.Random;

public class Insurance {

	InsuredValue insuredValue;

	public double calculatePolicyCharge(InsuredValue insuredValue) {
		return 0;
	}

	public int getRandomFixedFee(int min, int max) {
		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random fee = new Random();
		return fee.nextInt((max - min) + 1) + min;
	}
}
