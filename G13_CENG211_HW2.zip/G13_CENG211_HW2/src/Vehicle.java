
public class Vehicle extends InsuredValue {

	private String plateCity;
	private double engineVolume;
	private int yearOfProduction;
	private String typeOfGear;
	private int fuelTankVolume;

	public Vehicle(String insuranceNumber, int yearOfInsurance, String plateCity, double engineVolume,
			int yearOfProduction, String typeOfGear, int fuelTankVolume) {
		super(insuranceNumber, yearOfInsurance);
		this.plateCity = plateCity;
		this.engineVolume = engineVolume;
		this.yearOfProduction = yearOfProduction;
		this.typeOfGear = typeOfGear;
		this.fuelTankVolume = fuelTankVolume;
	}

	public String getPlateCity() {
		return plateCity;
	}

	public void setPlateCity(String plateCity) {
		this.plateCity = plateCity;
	}

	public double getEngineVolume() {
		return engineVolume;
	}

	public void setEngineVolume(double engineVolume) {
		this.engineVolume = engineVolume;
	}

	public int getYearOfProduction() {
		return yearOfProduction;
	}

	public void setYearOfProduction(int yearOfProduction) {
		this.yearOfProduction = yearOfProduction;
	}

	public String getTypeOfGear() {
		return typeOfGear;
	}

	public void setTypeOfGear(String typeOfGear) {
		this.typeOfGear = typeOfGear;
	}

	public int getFuelTankVolume() {
		return fuelTankVolume;
	}

	public void setFuelTankVolume(int fuelTankVolume) {
		this.fuelTankVolume = fuelTankVolume;
	}

	public double getPlateCityRiskFactorValue() {
		double plateCityRiskFactorValue = 0;
		if (plateCity.equals("Izmir")) {
			plateCityRiskFactorValue = 0.78;
		} else if (plateCity.equals("Istanbul")) {
			plateCityRiskFactorValue = 0.97;
		} else if (plateCity.equals("Ankara")) {
			plateCityRiskFactorValue = 0.85;
		} else
			plateCityRiskFactorValue = 0.65;
		return plateCityRiskFactorValue;
	}

	public double getTypeOfGearRiskFactorValue() {
		double typeOfGearRiskFactorValue = 0;
		if (typeOfGear.equals("manual")) {
			typeOfGearRiskFactorValue = 0.47;
		} else if (typeOfGear.equals("automatic")) {
			typeOfGearRiskFactorValue = 0.98;
		}
		return typeOfGearRiskFactorValue;
	}

}
