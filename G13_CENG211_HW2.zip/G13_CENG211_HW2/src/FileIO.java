import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class FileIO {

	private static ArrayList<InsuredValue> insuredValueList = new ArrayList<>();

	public static ArrayList<InsuredValue> read(String file) {
		BufferedReader br = null;
		String line = "";

		try {
			String insuranceNumber = "";
			int yearOfInsurance;
			String city;
			int numberOfFloors;
			int yearOfConstruction;
			String typeOfConstruction;
			int surfaceArea;
			int annualRevenue;
			String name;
			long nationalId;
			String gender;
			int yearOfBirth;
			String typeOfIllness;
			double engineVolume;
			int yearOfProduction;
			String typeOfGear;
			int fuelTankVolume;
			String typeOfRoof;
			String residentSituation;
			String typeOfTruckBed;

			br = new BufferedReader(new FileReader(file));

			StringTokenizer st = null;

			while ((line = br.readLine()) != null) {
				st = new StringTokenizer(line, ",");
				insuranceNumber = st.nextToken();

				if (insuranceNumber.charAt(0) == 'W') {

					yearOfInsurance = Integer.parseInt(st.nextToken());
					city = st.nextToken();
					numberOfFloors = Integer.parseInt(st.nextToken());
					yearOfConstruction = Integer.parseInt(st.nextToken());
					typeOfConstruction = st.nextToken();
					surfaceArea = Integer.parseInt(st.nextToken());
					annualRevenue = Integer.parseInt(st.nextToken());

					Workplace workplace = new Workplace(insuranceNumber, yearOfInsurance, city, numberOfFloors,
							yearOfConstruction, typeOfConstruction, surfaceArea, annualRevenue);
					insuredValueList.add(workplace);

				} else if (insuranceNumber.charAt(0) == 'H') {

					yearOfInsurance = Integer.parseInt(st.nextToken());
					city = st.nextToken();
					numberOfFloors = Integer.parseInt(st.nextToken());
					yearOfConstruction = Integer.parseInt(st.nextToken());
					typeOfConstruction = st.nextToken();
					surfaceArea = Integer.parseInt(st.nextToken());
					residentSituation = st.nextToken();

					Housing housing = new Housing(insuranceNumber, yearOfInsurance, city, numberOfFloors,
							yearOfConstruction, typeOfConstruction, surfaceArea, residentSituation);
					insuredValueList.add(housing);

				} else if (insuranceNumber.charAt(0) == 'P') {

					yearOfInsurance = Integer.parseInt(st.nextToken());
					city = st.nextToken();
					name = st.nextToken();
					nationalId = Long.parseLong(st.nextToken());
					gender = st.nextToken();
					yearOfBirth = Integer.parseInt(st.nextToken());
					typeOfIllness = st.nextToken();

					Person person = new Person(insuranceNumber, yearOfInsurance, city, name, nationalId, gender,
							yearOfBirth, typeOfIllness);
					insuredValueList.add(person);

				} else if (insuranceNumber.charAt(0) == 'A') {

					yearOfInsurance = Integer.parseInt(st.nextToken());
					city = st.nextToken();
					engineVolume = Double.parseDouble(st.nextToken());
					yearOfProduction = Integer.parseInt(st.nextToken());
					typeOfGear = st.nextToken();
					fuelTankVolume = Integer.parseInt(st.nextToken());
					typeOfRoof = st.nextToken();

					Automobile automobile = new Automobile(insuranceNumber, yearOfInsurance, city, engineVolume,
							yearOfProduction, typeOfGear, fuelTankVolume, typeOfRoof);
					insuredValueList.add(automobile);

				} else if (insuranceNumber.charAt(0) == 'T') {

					yearOfInsurance = Integer.parseInt(st.nextToken());
					city = st.nextToken();
					engineVolume = Double.parseDouble(st.nextToken());
					yearOfProduction = Integer.parseInt(st.nextToken());
					typeOfGear = st.nextToken();
					fuelTankVolume = Integer.parseInt(st.nextToken());
					typeOfTruckBed = st.nextToken();

					Truck truck = new Truck(insuranceNumber, yearOfInsurance, city, engineVolume, yearOfProduction,
							typeOfGear, fuelTankVolume, typeOfTruckBed);
					insuredValueList.add(truck);
				}

			}

		} catch (Exception e) {
			System.out.println("Exception while reading csv file: " + e);
		}
		return insuredValueList;

	}

}