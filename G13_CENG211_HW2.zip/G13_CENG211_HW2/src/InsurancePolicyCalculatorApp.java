import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class InsurancePolicyCalculatorApp {

	public static void main(String[] args) throws IOException {

		Insurance insurance = new Insurance();
		PolicyRecord policyRecord = new PolicyRecord();

		Scanner keyboard = new Scanner(System.in);

		System.out.println("1 All insured values, 2 Workplaces, 3 Housings, 4 Persons, 5 Automobiles, 6 Trucks.");

		System.out.println("Please enter your choice: ");

		int choice = keyboard.nextInt();

		if (choice == 1) {
			ArrayList<InsuredValue> ivW = policyRecord.getWorkPlaceList();
			Household household = new Household();
			Health health = new  Health();
			Traffic traffic = new  Traffic();
			for (int i = 0; i < ivW.size(); i++) {
				double result =household.calculatePolicyCharge(ivW.get(i));
				System.out.println("Insured Value: Workplace Insurance Number : " + ivW.get(i).getInsuranceNumber()
						+ " Year of Insurance : " + ivW.get(i).getYearOfInsurance());
				System.out.println("The policy charge of " + result + " TL.");

			}
			ArrayList<InsuredValue> ivH = policyRecord.getHousingList();
			for (int i = 0; i < ivH.size(); i++) {
				double result = household.calculatePolicyCharge(ivH.get(i));
				System.out.println("Insured Value: Housing Insurance Number : " + ivH.get(i).getInsuranceNumber()
						+ " Year of Insurance : " + ivH.get(i).getYearOfInsurance());
				System.out.println("The policy charge of " + result + " TL.");
			}
			ArrayList<InsuredValue> ivP = policyRecord.getPersonList();
			for (int i = 0; i < ivP.size(); i++) {
				double result = health.calculatePolicyCharge(ivP.get(i));
				System.out.println("Insured Value: Person Insurance Number : " + ivP.get(i).getInsuranceNumber()
						+ " Year of Insurance : " + ivP.get(i).getYearOfInsurance());
				System.out.println("The policy charge of " + result + " TL.");
			}
			ArrayList<InsuredValue> ivA = policyRecord.getAutomobileList();
			for (int i = 0; i < ivA.size(); i++) {
				double result = traffic.calculatePolicyCharge(ivA.get(i));
				System.out.println("Insured Value: Automobile Insurance Number : " + ivA.get(i).getInsuranceNumber()
						+ " Year of Insurance : " + ivA.get(i).getYearOfInsurance());
				System.out.println("The policy charge of " + result + " TL.");
			}
			ArrayList<InsuredValue> ivT = policyRecord.getTruckList();
			for (int i = 0; i < ivT.size(); i++) {
				double result = traffic.calculatePolicyCharge(ivT.get(i));
				System.out.println("Insured Value: Truck Insurance Number : " + ivT.get(i).getInsuranceNumber()
						+ " Year of Insurance : " + ivT.get(i).getYearOfInsurance());
				System.out.println("The policy charge of " + result + " TL.");
			}
		} else if (choice == 2) {
			ArrayList<InsuredValue> iv = policyRecord.getWorkPlaceList();
			Household h = new Household();
			for (int i = 0; i < iv.size(); i++) {
				double result = h.calculatePolicyCharge(iv.get(i));
				System.out.println("Insured Value: Workplace Insurance Number : " + iv.get(i).getInsuranceNumber()
						+ " Year of Insurance : " + iv.get(i).getYearOfInsurance());
				System.out.println("The policy charge of " + result + " TL.");
			}

		} else if (choice == 3) {
			ArrayList<InsuredValue> iv = policyRecord.getHousingList();
			Household h = new Household();
			for (int i = 0; i < iv.size(); i++) {
				double result = h.calculatePolicyCharge(iv.get(i));
				System.out.println("Insured Value: Housing Insurance Number : " + iv.get(i).getInsuranceNumber()
						+ " Year of Insurance : " + iv.get(i).getYearOfInsurance());
				System.out.println("The policy charge of " + result + " TL.");
			}
		} else if (choice == 4) {
			ArrayList<InsuredValue> iv = policyRecord.getPersonList();
			Health h = new Health();
			for (int i = 0; i < iv.size(); i++) {
				
				double result = h.calculatePolicyCharge(iv.get(i));
				System.out.println("Insured Value: Person Insurance Number : " + iv.get(i).getInsuranceNumber()
						+ " Year of Insurance : " + iv.get(i).getYearOfInsurance());
				System.out.println("The policy charge of " + result + " TL.");
			}
		} else if (choice == 5) {
			ArrayList<InsuredValue> iv = policyRecord.getAutomobileList();
			Traffic t  = new  Traffic();
			for (int i = 0; i < iv.size(); i++) {
				double result = t.calculatePolicyCharge(iv.get(i));
				System.out.println("Insured Value: Automobile Insurance Number : " + iv.get(i).getInsuranceNumber()
						+ " Year of Insurance : " + iv.get(i).getYearOfInsurance());
				System.out.println("The policy charge of " + result + " TL.");
			}
		} else if (choice == 6) {
			ArrayList<InsuredValue> iv = policyRecord.getTruckList();
			Traffic t  = new  Traffic();
			for (int i = 0; i < iv.size(); i++) {
				double result = t.calculatePolicyCharge(iv.get(i));
				System.out.println("Insured Value: Truck Insurance Number : " + iv.get(i).getInsuranceNumber()
						+ " Year of Insurance : " + iv.get(i).getYearOfInsurance());
				System.out.println("The policy charge of " + result + " TL.");
			}
		}

		keyboard.close();
	}

}
