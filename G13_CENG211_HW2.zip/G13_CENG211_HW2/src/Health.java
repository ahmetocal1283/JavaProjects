
public class Health extends Insurance {

	public Health() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculatePolicyCharge(InsuredValue insuredValue) {
		double result = 0;
		double riskFactor = insuredValue.calculateRiskFactor();
		double fixedFee = getRandomFixedFee(1000, 3000);
		result = (fixedFee * Math.pow(riskFactor, 3)) / 208;
		double rank = 2020 - insuredValue.getYearOfInsurance();
		if ((riskFactor > 50) && (rank < 3)) {
			result = 1000000000;
			System.out.println();
			System.out.println("The insurance application is denied");
			System.out.println();

		}
		return result;

	}

}
