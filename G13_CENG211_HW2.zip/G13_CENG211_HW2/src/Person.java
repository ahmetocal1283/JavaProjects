
public class Person extends InsuredValue {


	private String residenceCity;
	private String name;
	private long nationalId;
	private String gender;
	private int yearOfBirth;
	private String typeOfIllness;
	

	public Person(String insuranceNumber, int yearOfInsurance, String residenceCity, String name, long nationalId, String gender,
			int yearOfBirth, String typeOfIllness) {
		super(insuranceNumber, yearOfInsurance);
		this.residenceCity = residenceCity;
		this.name = name;
		this.nationalId = nationalId;
		this.gender = gender;
		this.yearOfBirth = yearOfBirth;
		this.typeOfIllness = typeOfIllness;
	}


	@Override
	public double calculateRiskFactor() {
		return ((2020-yearOfBirth)^2) / (getTypeOfChronicleIllnessRiskFactorValue()*18) ;
	}
	public String getResidenceCityy() {
		return residenceCity;
	}
	public void setResidenceCity(String residenceCity) {
		this.residenceCity = residenceCity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getNationalId() {
		return nationalId;
	}
	public void setNationalId(int nationalId) {
		this.nationalId = nationalId;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getYearOfBirth() {
		return yearOfBirth;
	}
	public void setYearOfBirth(int yearOfBirth) {
		this.yearOfBirth = yearOfBirth;
	}
	public String getTypeOfIllness() {
		return typeOfIllness;
	}
	public void setTypeOfIllness(String typeOfIllness) {
		this.typeOfIllness = typeOfIllness;
	}
	
	public double getTypeOfChronicleIllnessRiskFactorValue() {
		double chronicleIllnessRiskFactorValue = 0;
		if(typeOfIllness.equals("cardiovascular")) {
			chronicleIllnessRiskFactorValue = 1.85;
		}
		else if(typeOfIllness.equals("diabetes")) {
			chronicleIllnessRiskFactorValue = 1.84;
		}
		else if(typeOfIllness.equals("respiratory")) {
			chronicleIllnessRiskFactorValue = 1.86;
		}
		else if(typeOfIllness.equals("none")) {
			chronicleIllnessRiskFactorValue = 0.1;
		}
		else
			chronicleIllnessRiskFactorValue = 1.8;
		return chronicleIllnessRiskFactorValue;
	}
}
