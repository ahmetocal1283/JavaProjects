
public class Automobile extends Vehicle {

	private String typeOfRoof;

	public Automobile(String insuranceNumber, int yearOfInsurance, String plateCity, double engineVolume,
			int yearOfProduction, String typeOfGear, int fuelTankVolume, String typeOfRoof) {
		super(insuranceNumber, yearOfInsurance, plateCity, engineVolume, yearOfProduction, typeOfGear, fuelTankVolume);
		this.typeOfRoof = typeOfRoof;
	}

	@Override
	public double calculateRiskFactor() {
		double result;

		result = (getEngineVolume() * (0.004 * getFuelTankVolume()) * (2020 - getYearOfProduction())
				* (getPlateCityRiskFactorValue() * 0.03)) / getTypeOfRoofRiskFactorValue();
		return result;
	}

	public String getTypeOfRoof() {
		return typeOfRoof;
	}

	public void setTypeOfRoof(String typeOfRoof) {
		this.typeOfRoof = typeOfRoof;
	}
	
	public double getTypeOfRoofRiskFactorValue() {
		double typeOfRoofRiskFactorValue = 0;
		if(typeOfRoof.equals("regular")) {
			typeOfRoofRiskFactorValue=0.87;
		}
		else if(typeOfRoof.equals("sunroof")) {
			typeOfRoofRiskFactorValue=0.64;
		}
		else if(typeOfRoof.equals("moonroof")) {
			typeOfRoofRiskFactorValue=0.48;
		}
		return typeOfRoofRiskFactorValue ;
	}

}
